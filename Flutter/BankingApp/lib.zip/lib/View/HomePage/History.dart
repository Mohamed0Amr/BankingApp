import 'package:bankingapp/Components/History/summary_card.dart';
import 'package:bankingapp/Components/History/transaction_card.dart';
import 'package:bankingapp/Components/History/transaction_details.dart';
import 'package:bankingapp/Services/History/history_controller.dart';
import 'package:bankingapp/Components/History/filter_dialog.dart';
import 'package:flutter/material.dart';


class HistoryScreen extends StatefulWidget {
  const HistoryScreen({super.key});

  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  final _controller = HistoryController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Transaction History'),
        actions: [
          IconButton(
            icon: const Icon(Icons.filter_list),
            onPressed: () => _showFilterDialog(context),
          ),
        ],
      ),
      body: Column(
        children: [
          SummaryCard(
            income: _controller.totalIncome,
            expenses: _controller.totalExpenses.abs(),
            balance: _controller.netBalance,
          ),
          Expanded(
            child: ListView.builder(
              itemCount: _controller.transactions.length,
              itemBuilder: (context, index) {
                final transaction = _controller.transactions[index];
                return TransactionCard(
                  transaction: transaction,
                  onTap: () => _showTransactionDetails(context, transaction),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  void _showTransactionDetails(BuildContext context, Map<String, dynamic> transaction) {
    showModalBottomSheet(
      context: context,
      builder: (context) => TransactionDetails(transaction: transaction),
    );
  }

  void _showFilterDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => const FilterDialog(),
    );
  }
}