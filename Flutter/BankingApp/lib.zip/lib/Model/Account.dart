// models/account.dart
class Account {
  final String accountNumber;
  final String accountType;
  final double balance;

  Account({
    required this.accountNumber,
    required this.accountType,
    required this.balance,
  });

  factory Account.fromJson(Map<String, dynamic> json) {
    return Account(
      accountNumber: json['account_number'] as String,
      accountType: json['account_type'] as String,
      balance: (json['balance'] as num).toDouble(),
    );
  }

  Map<String, dynamic> toJson() => {
    'account_number': accountNumber,
    'account_type': accountType,
    'balance': balance,
  };

  @override
  String toString() {
    return 'Account($accountNumber, $accountType, \$$balance)';
  }
}